# LineFollower

Line Follower is a project for ECE1188 Cyber-Physical Systems. Its goal is to utilize reflectance sensors and motors on the TI-RSLK Max to race the robot around a track made of black tape. 

Our group consists of Aurimas Balciunas, Zack Benning, Austin Jadliowec, and Benjamin Nguyen.

